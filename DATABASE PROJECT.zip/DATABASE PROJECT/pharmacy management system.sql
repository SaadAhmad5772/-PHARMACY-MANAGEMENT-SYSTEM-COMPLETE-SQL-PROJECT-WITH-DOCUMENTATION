/* ================================
   PHARMACY MANAGEMENT SYSTEM
   COMPLETE SQL PROJECT
   ================================ */

DROP DATABASE IF EXISTS PharmacyDB;
CREATE DATABASE PharmacyDB;
USE PharmacyDB;

/* ================================
   TABLE CREATION
   ================================ */

CREATE TABLE Branch (
    BranchID INT PRIMARY KEY,
    BranchName VARCHAR(50),
    Location VARCHAR(50),
    ContactNo VARCHAR(15)
);

CREATE TABLE Staff (
    StaffID INT PRIMARY KEY,
    StaffName VARCHAR(50),
    ContactNo VARCHAR(15),
    Designation VARCHAR(30),
    BranchID INT,
    FOREIGN KEY (BranchID) REFERENCES Branch(BranchID)
);

CREATE TABLE Customer (
    CustomerID INT PRIMARY KEY,
    CustomerName VARCHAR(50),
    ContactNo VARCHAR(15)
);

CREATE TABLE Medicine (
    MedicineID INT PRIMARY KEY,
    MedicineName VARCHAR(50),
    Category VARCHAR(30),
    ExpiryDate DATE,
    SalePrice INT
);

CREATE TABLE Inventory (
    InventoryID INT PRIMARY KEY,
    BranchID INT,
    MedicineID INT,
    StockQuantity INT,
    StockStatus VARCHAR(20),
    LastUpdated DATE,
    FOREIGN KEY (BranchID) REFERENCES Branch(BranchID),
    FOREIGN KEY (MedicineID) REFERENCES Medicine(MedicineID)
);

CREATE TABLE Sales (
    SaleID INT PRIMARY KEY,
    SaleDate DATE,
    TotalAmount INT,
    PaymentMethod VARCHAR(20),
    CustomerID INT,
    StaffID INT,
    BranchID INT,
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID),
    FOREIGN KEY (StaffID) REFERENCES Staff(StaffID),
    FOREIGN KEY (BranchID) REFERENCES Branch(BranchID)
);

/* ================================
   INSERT DATA
   ================================ */

INSERT INTO Branch VALUES
(1,'City Pharmacy','Lahore','03001111111'),
(2,'HealthPlus','Karachi','03002222222'),
(3,'LifeCare','Islamabad','03003333333'),
(4,'MedPoint','Faisalabad','03004444444'),
(5,'Wellness','Multan','03005555555'),
(6,'Care Pharmacy','Rawalpindi','03006666666');

INSERT INTO Staff VALUES
(1,'Ali Khan','03111111111','Pharmacist',1),
(2,'Sara Ahmed','03222222222','Manager',2),
(3,'Usman Raza','03333333333','Salesman',3),
(4,'Ayesha Noor','03444444444','Pharmacist',4),
(5,'Bilal Hussain','03555555555','Salesman',5),
(6,'Hina Shah','03666666666','Manager',6);

INSERT INTO Customer VALUES
(1,'Ahmed Ali','03009999991'),
(2,'Fatima Noor','03009999992'),
(3,'Hamza Khan','03009999993'),
(4,'Zara Sheikh','03009999994'),
(5,'Saad Malik','03009999995'),
(6,'Areeba Iqbal','03009999996');

INSERT INTO Medicine VALUES
(101,'Panadol','Tablet','2026-05-10',50),
(102,'Brufen','Tablet','2026-08-15',120),
(103,'Disprin','Tablet','2025-12-20',40),
(104,'Augmentin','Syrup','2026-03-18',450),
(105,'Calpol','Syrup','2026-07-25',90),
(106,'Flagyl','Tablet','2025-11-30',80);

INSERT INTO Inventory VALUES
(1,1,101,200,'Available','2026-01-01'),
(2,1,102,150,'Available','2026-01-01'),
(3,2,103,300,'Available','2026-01-01'),
(4,3,104,100,'Low','2026-01-01'),
(5,4,105,250,'Available','2026-01-01'),
(6,5,106,90,'Low','2026-01-01');

INSERT INTO Sales VALUES
(1,'2026-01-05',200,'Cash',1,1,1),
(2,'2026-01-06',450,'Card',2,2,2),
(3,'2026-01-07',120,'Cash',3,3,3),
(4,'2026-01-08',90,'Cash',4,4,4),
(5,'2026-01-09',300,'Card',5,5,5),
(6,'2026-01-10',80,'Cash',6,6,6);

/* ================================
   REQUIRED SQL OPERATIONS
   ================================ */

-- Retrieve all records
SELECT * FROM Medicine;

-- Retrieve specific columns
SELECT MedicineName, SalePrice FROM Medicine;

-- Update existing record
UPDATE Medicine SET SalePrice = 55 WHERE MedicineID = 101;

-- Delete a record
DELETE FROM Inventory WHERE InventoryID = 6;

-- Search using keyword
SELECT * FROM Medicine WHERE MedicineName LIKE '%Cal%';

-- Filter records
SELECT * FROM Medicine WHERE SalePrice > 100;

-- Multiple conditions
SELECT * FROM Medicine WHERE SalePrice > 50 AND Category = 'Tablet';

-- Count records
SELECT COUNT(*) AS TotalMedicines FROM Medicine;

-- Maximum value
SELECT MAX(SalePrice) AS MaxPrice FROM Medicine;

-- Minimum value
SELECT MIN(SalePrice) AS MinPrice FROM Medicine;

-- Average value
SELECT AVG(SalePrice) AS AvgPrice FROM Medicine;

-- Group by
SELECT Category, COUNT(*) AS Total FROM Medicine GROUP BY Category;

-- INNER JOIN
SELECT S.SaleID, C.CustomerName
FROM Sales S
INNER JOIN Customer C ON S.CustomerID = C.CustomerID;

-- LEFT JOIN
SELECT C.CustomerName, S.SaleID
FROM Customer C
LEFT JOIN Sales S ON C.CustomerID = S.CustomerID;

-- Multiple table join
SELECT S.SaleID, C.CustomerName, B.BranchName
FROM Sales S
JOIN Customer C ON S.CustomerID = C.CustomerID
JOIN Branch B ON S.BranchID = B.BranchID;

-- Subquery
SELECT MedicineName
FROM Medicine
WHERE SalePrice > (SELECT AVG(SalePrice) FROM Medicine);

-- Greater than average
SELECT * FROM Medicine
WHERE SalePrice > (SELECT AVG(SalePrice) FROM Medicine);

-- Sort ascending
SELECT * FROM Medicine ORDER BY SalePrice ASC;

-- Sort descending
SELECT * FROM Medicine ORDER BY SalePrice DESC;

-- Top N records
SELECT * FROM Medicine ORDER BY SalePrice DESC LIMIT 3;